#include <stdio.h>


int main (){
	int i;
	for (i = 10; i < 130; i++){
		printf("%d %c\n", i, i);
	}
	return 0;
	
	/*
	char a = "a";

	if (a == "a"){
		printf("test");
	}
	*/
}