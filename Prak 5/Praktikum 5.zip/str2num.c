// NIM                      : 13521116
// Nama                     : Juan Christopher Santoso
// Tanggal                  : 29 September 2022
// Topik praktikum          : Praktikum 5
// Deskripsi                : Menghitung kata yang paling panjang dari input

#include <stdio.h>
#include "wordmachine.c"
#include "charmachine.c"
#include "boolean.h"

boolean EndWord;
Word currentWord;

int main (){
	int i;
	STARTWORD();
	int length;

	while (!EndWord){
		//char *word = "";
		for (i = 0 ; i < currentWord.TabWord[i] ; i++){
			length = currentWord.Length;
			char word [length];
			word[i] = currentWord.TabWord[i];
		}
		if (word == "satu\0"){
			printf("1");
		} else {
			for (i = 0; i < currentWord.Length; i++){
				printf("%c", currentWord.TabWord[i]);
			}
		}

		printf(" ");

		ADVWORD();
	}

	printf("\n");


	return 0;
}