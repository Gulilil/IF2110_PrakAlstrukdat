/*
    NIM                     : 13521116
    Nama                    : Juan Christopher Santoso
    Tanggal                 : 6 November 2022
    Topik praktikum         : Praktikum 10
    Deskripsi               : Menggunakan stack untuk perhitungan string
*/

#include "boolean.h"
#include "stacklinked.h"
#include <stdio.h>
#include "charmachine.h"

int main () {
    Stack s;
    CreateStack(&s);
    int nsiku = 0;
    int nbulat = 0;
    int ntegak = 0;
    int nkurawal = 0;
    int nsegitiga = 0;
    boolean valid = true;
    int max = 0;
    int val;
    START();
    while(currentChar != '.'){
        //printf("%c\n", currentChar);
        boolean newTegak = false; // untuk handle kurung tegak
        // Penambahan
        if(currentChar == '['){
            push(&s, 0);
            nsiku++;
            DisplayStack(s);
            printf("\n");
        } else if (currentChar == '('){
            push(&s, 1);
            nbulat++;
            DisplayStack(s);
            printf("\n");
        } else if (currentChar == '|'){

            // cari apakah | adalah yang pembuka atau penutup
            boolean found = false;
            Address p = ADDR_TOP(s);
            while (p != NULL){
                if (INFO(p) == 2){
                    found = true;
                }
                p = NEXT(p);
            }
            if (!found){
                push(&s, 2);
                ntegak++;
                DisplayStack(s);
                printf("\n");
            } else {
                if (!isEmpty(s)){
                    pop(&s, &val);
                    if (val != 2){
                        valid = false;
                        push(&s,val);
                    }
                }
                else {
                    valid = false;
                }
                DisplayStack(s);
                printf("\n");
            }

        } else if (currentChar == '{'){
            push(&s, 3);
            nkurawal++;
            DisplayStack(s);
            printf("\n");
        } else if (currentChar == '<'){
            push(&s, 4);
            nsegitiga++;
            DisplayStack(s);
            printf("\n");
        }
        int len = length(s);
        if (len > max){
            max = len;
        }

        // Pengurangan
        if (currentChar == ']'){
            if (!isEmpty(s)){
                pop(&s, &val);
                if (val != 0){
                    valid = false;
                    push(&s,val);
                }
            }
            else {
                valid = false;
            }
            DisplayStack(s);
            printf("\n");
        }
        else if (currentChar == ')'){
            if (!isEmpty(s)){
                pop(&s, &val);

                if (val != 1){
                    valid = false;
                    push(&s,val);
                }
            }
            else {
                valid = false;
            }
            DisplayStack(s);
            printf("\n");
        }
        else if (currentChar == '}'){
            if (!isEmpty(s)){
                pop(&s, &val);
                if (val != 3){
                    valid = false;
                    push(&s,val);
                }
            }
            else {
                valid = false;
            }
            DisplayStack(s);
            printf("\n");
        }
        else if (currentChar == '>'){
            if (!isEmpty(s)){
                pop(&s, &val);
                if (val != 4){
                    valid = false;
                    push(&s,val);
                }
            }
            else {
                valid = false;
            }
            DisplayStack(s);
            printf("\n");
        }
        //printf("%c", currentChar);
        ADV();
    }
    if (valid && isEmpty(s)){
        printf("kurung valid\n");
        printf("[%d](%d)|%d|{%d}<%d>\n", nsiku, nbulat, ntegak, nkurawal, nsegitiga);
        printf("MAX %d\n", max);
    } else {
        printf("kurung tidak valid\n");
    }
    return 0;
}

/*
<5,2> dan <7,3> adalah koordinat rahasia dan disana ada agen dengan id {1,8,2,1,3,5}.

[(1+1)*(7/3)-|(6/3+-2*9)|] =x.

[f{e<a}d>c].

(: semoga harimu menyenangkan.

:) semoga harimu menyenangkan.

Hai.
*/